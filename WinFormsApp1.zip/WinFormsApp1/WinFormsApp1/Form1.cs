using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            this.FormClosing += Form1_FormClosing;
            InitializeComponent();
            AttachEventHandlers();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("�������?", "Message", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string firstName = textBox1.Text;
            string lastName = textBox2.Text;
            string middleName = textBox3.Text;

            if (IsAllLetters(firstName) && IsAllLetters(lastName) && IsAllLetters(middleName))
            {
                string fullName = $"{firstName} {lastName} {middleName}";
                listBox1.Items.Add(fullName);
            }
            else
            {
                MessageBox.Show("����� ������ ��������� ������ �����", "������");
            }
        }

        private bool IsAllLetters(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void SetTextBoxBackgroundColor(System.Windows.Forms.TextBox textBox, string grade)
        {
            switch (grade)
            {
                case "5":
                    textBox.BackColor = Color.Green;
                    break;
                case "4":
                    textBox.BackColor = Color.Orange;
                    break;
                case "3":
                    textBox.BackColor = Color.Yellow;
                    break;
                case "2":
                    textBox.BackColor = Color.Red;
                    break;
                default:
                    textBox.BackColor = SystemColors.Window;
                    break;
            }
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }
        private void textBox_TextChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)sender;


            if (!IsValidGrade(textBox.Text))
            {
                textBox.Text = string.Empty;
            }
        }

        private void ClearGrades()
        {
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string studentName = listBox1.SelectedItem.ToString();

                if (!string.IsNullOrWhiteSpace(textBox3.Text) &&
                    !string.IsNullOrWhiteSpace(textBox2.Text) &&
                    !string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    // ������������ ������ � ��������
                    string grades = $"{studentName}: ���������� - {textBox4.Text}, �������� - {textBox5.Text}, �������� - {textBox6.Text}";


                    string filePath = $"./������-{studentName}.txt";

                    DialogResult result = MessageBox.Show("������ ��������� ������ � ����?", "���������� ������", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        File.WriteAllText(filePath, grades);

                        MessageBox.Show("������ ��������� � ����", "�������");
                    }
                }
                else
                {
                    MessageBox.Show("������� ������ ����� �����������", "��������");
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            SetTextBoxBackgroundColor(textBox4, textBox4.Text);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            SetTextBoxBackgroundColor(textBox5, textBox5.Text);
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            SetTextBoxBackgroundColor(textBox6, textBox6.Text);
        }
        private bool IsValidGrade(string input)
        {

            return input == "2" || input == "3" || input == "4" || input == "5";
        }

        private void AttachEventHandlers()
        {
            textBox4.KeyPress += textBox_KeyPress;
            textBox5.KeyPress += textBox_KeyPress;
            textBox6.KeyPress += textBox_KeyPress;

            textBox4.TextChanged += textBox_TextChanged;
            textBox5.TextChanged += textBox_TextChanged;
            textBox6.TextChanged += textBox_TextChanged;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string studentName = listBox1.SelectedItem.ToString();
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);

                ClearGrades();
                string filePath = $"C:\\Users\\daniil.shashirin\\source\repos\\WinFormsApp1\\WinFormsApp1\\bin\\Debug������-{studentName}.txt";

                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
            }
            else
            {
                MessageBox.Show("�������� ������� ��� ��������", "��������");
            }
        }

    }
}